# parcel-react

[![Slack](https://slack-the-road-to-learn-react.wieruch.com/badge.svg)](https://slack-the-road-to-learn-react.wieruch.com/)

A minimal React.js boilerplate with [parcel as bundler](https://github.com/parcel-bundler/parcel). Parcel is an alternative web application bundler to Webpack. Read more about it: [Getting started with React and Parcel](https://www.robinwieruch.de/parcel-react-setup/).

## Installation

* `git clone git@github.com:rwieruch/parcel-react.git`
* `cd parcel-react`
* `npm install`
* `npm start`
